<?php namespace Illuminate\Contracts\Queue;

interface ShouldBeQueued {}
