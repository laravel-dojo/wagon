CHANGELOG
=========

* 1.0.4 (2016-06-02)

  * Add compability with Symfony 3.

* 1.0.3 (2014-11-23)

  * Only call Terminable middlewares once.

* 1.0.2 (2014-05-18)

  * Validate missing arguments (@bajbnet).

* 1.0.1 (2013-10-25)

  * Lower PHP requirement to 5.3.

* 1.0.0 (2013-08-02)

  * Initial release.
