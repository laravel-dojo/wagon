<?php

namespace My\Example;

use Mockery as m;
use phpDocumentor\Reflection\Types;

class Classy
{
    /**
     * @var Types\Context
     */
    public function __construct($context)
    {
    }
}
