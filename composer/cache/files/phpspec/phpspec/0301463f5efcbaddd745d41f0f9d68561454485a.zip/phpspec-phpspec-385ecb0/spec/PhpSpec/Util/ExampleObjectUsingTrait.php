<?php

namespace spec\PhpSpec\Util;

class ExampleObjectUsingTrait
{
    use ExampleTrait, AnotherExampleTrait;
}
