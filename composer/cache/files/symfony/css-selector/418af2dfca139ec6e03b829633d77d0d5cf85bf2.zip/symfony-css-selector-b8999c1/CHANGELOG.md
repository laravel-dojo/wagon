CHANGELOG
=========

2.8.0
-----

 * Added the `CssSelectorConverter` class as a non-static API for the component.
 * Deprecated the `CssSelector` static API of the component.

2.1.0
-----

 * none
