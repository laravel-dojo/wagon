<?php
class NewException extends Exception
{
}
