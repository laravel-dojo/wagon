<?php
class Issue1330Test extends PHPUnit_Framework_TestCase
{
    public function testTrue()
    {
        $this->assertTrue(PHPUNIT_1330);
    }
}
