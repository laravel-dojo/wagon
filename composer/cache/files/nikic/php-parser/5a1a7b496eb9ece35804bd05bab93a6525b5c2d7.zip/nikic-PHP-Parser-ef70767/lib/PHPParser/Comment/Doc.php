<?php

class PHPParser_Comment_Doc extends PHPParser_Comment
{
}