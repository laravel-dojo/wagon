<?php

abstract class PHPParser_Node_Expr extends PHPParser_NodeAbstract
{
}