<?php

namespace Illuminate\Foundation\Validation;

use Illuminate\Validation\ValidationException as BaseException;

/**
 * @deprecated since 5.2.7. Use Illuminate\Validation\ValidationException.
 */
class ValidationException extends BaseException
{
}
